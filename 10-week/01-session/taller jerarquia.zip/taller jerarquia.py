+from abc import ABC, abstractmethod
import math

# ==============================================================
# CLASE BASE ABSTRACTA
# ==============================================================

class FiguraGeometrica(ABC):
    """Clase base abstracta que define la estructura común de las figuras geométricas."""

    def __init__(self, color: str):
        if not color or not isinstance(color, str):
            raise ValueError("El color debe ser una cadena de texto no vacía.")
        self._color = color  # Encapsulamiento (atributo protegido)

    @abstractmethod
    def area(self) -> float:
        """Método abstracto que calculará el área de la figura."""
        pass

    @abstractmethod
    def perimetro(self) -> float:
        """Método abstracto que calculará el perímetro de la figura."""
        pass

    def descripcion(self) -> str:
        """Devuelve una descripción general de la figura."""
        return f"Figura de color {self._color}"

# ==============================================================
# SUBCLASE: RECTÁNGULO
# ==============================================================

class Rectangulo(FiguraGeometrica):
    def __init__(self, ancho: float, alto: float, color: str):
        super().__init__(color)
        if ancho <= 0 or alto <= 0:
            raise ValueError("El ancho y el alto deben ser positivos.")
        self.__ancho = ancho
        self.__alto = alto

    def area(self) -> float:
        return self.__ancho * self.__alto

    def perimetro(self) -> float:
        return 2 * (self.__ancho + self.__alto)

    def descripcion(self) -> str:
        return f"Rectángulo color {self._color} de {self.__ancho}x{self.__alto}"

# ==============================================================
# SUBCLASE: CÍRCULO
# ==============================================================

class Circulo(FiguraGeometrica):
    def __init__(self, radio: float, color: str):
        super().__init__(color)
        if radio <= 0:
            raise ValueError("El radio debe ser positivo.")
        self.__radio = radio

    def area(self) -> float:
        return math.pi * (self.__radio ** 2)

    def perimetro(self) -> float:
        return 2 * math.pi * self.__radio

    def descripcion(self) -> str:
        return f"Círculo color {self._color} de radio {self.__radio}"

# ==============================================================
# SUBCLASE: TRIÁNGULO
# ==============================================================

class Triangulo(FiguraGeometrica):
    def __init__(self, lado1: float, lado2: float, lado3: float, color: str):
        super().__init__(color)
        if lado1 <= 0 or lado2 <= 0 or lado3 <= 0:
            raise ValueError("Los lados deben ser positivos.")
        if (lado1 + lado2 <= lado3) or (lado1 + lado3 <= lado2) or (lado2 + lado3 <= lado1):
            raise ValueError("Los lados no cumplen la desigualdad triangular.")
        self.__lado1 = lado1
        self.__lado2 = lado2
        self.__lado3 = lado3

    def area(self) -> float:
        s = self.perimetro() / 2
        return math.sqrt(s * (s - self.__lado1) * (s - self.__lado2) * (s - self.__lado3))

    def perimetro(self) -> float:
        return self.__lado1 + self.__lado2 + self.__lado3

    def descripcion(self) -> str:
        return f"Triángulo color {self._color} con lados {self.__lado1}, {self.__lado2}, {self.__lado3}"

# ==============================================================
# FUNCIONES DEL MENÚ
# ==============================================================

def crear_figura():
    print("\n--- CREACIÓN DE FIGURA GEOMÉTRICA ---")
    print("1. Rectángulo")
    print("2. Círculo")
    print("3. Triángulo")
    print("0. Volver al menú principal")

    opcion = input("Seleccione una opción: ").strip()
    if opcion == '0':
        return None

    color = input("Ingrese el color de la figura: ").strip()

    try:
        if opcion == '1':
            ancho = float(input("Ingrese el ancho: "))
            alto = float(input("Ingrese el alto: "))
            return Rectangulo(ancho, alto, color)
        elif opcion == '2':
            radio = float(input("Ingrese el radio: "))
            return Circulo(radio, color)
        elif opcion == '3':
            lado1 = float(input("Ingrese el lado 1: "))
            lado2 = float(input("Ingrese el lado 2: "))
            lado3 = float(input("Ingrese el lado 3: "))
            return Triangulo(lado1, lado2, lado3, color)
        else:
            print("Opción no válida.")
    except ValueError as e:
        print(f"Error: {e}")
    return None

def mostrar_figuras(figuras):
    if not figuras:
        print("\nNo hay figuras registradas.")
        return
    print("\n--- LISTA DE FIGURAS ---")
    for i, figura in enumerate(figuras, 1):
        print(f"\n[{i}] {figura.descripcion()}")
        print
